CARBON_HOME/lib contains all the libraries necessary to run Carbon in
standalone mode

1. endorsed
   Endorsed Java libraries.

2. tomcat
   Temporary files created by the JSP compiler are stored here.

3. README.txt
   This file.

4. transactions.properties
   Atomikos properties file.      
