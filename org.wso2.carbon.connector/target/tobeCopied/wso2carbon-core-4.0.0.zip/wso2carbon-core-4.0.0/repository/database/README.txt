Application database resides in this directory.
