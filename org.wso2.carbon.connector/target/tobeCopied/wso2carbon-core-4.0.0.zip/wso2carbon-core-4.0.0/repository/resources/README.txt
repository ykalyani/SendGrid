Contains additional resources that may be required by Carbon

1. security
   Security related resource files such as keystores 