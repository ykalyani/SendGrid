This directory can be used to deploy all kind of deployable artifacts in Carbon.
The 'server' directory is the place to deploy all your services, modules etc.
The 'client' directory is used as the client side repository for all admin service
calls internally in Carbon.

You can have following directories inside the 'server' folder

axis2services - for AAR service deployment
axis2modules - for .mar module deployment
servicejars - for JAX-WS service deployment
dataservices - for data service deployment
webapps - Directory used for hosting webapps
